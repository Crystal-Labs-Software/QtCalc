#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include <QString>

double temp;
double result;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{   
    delete ui;
}


void MainWindow::on_pushButton1_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "1");

}

void MainWindow::on_pushButton2_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "2");

}

void MainWindow::on_pushButton3_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "3");

}

void MainWindow::on_pushButton4_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "4");

}

void MainWindow::on_pushButton5_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "5");

}

void MainWindow::on_pushButton6_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "6");

}

void MainWindow::on_pushButton7_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "7");

}

void MainWindow::on_pushButton8_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "8");

}

void MainWindow::on_pushButton9_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "9");

}

void MainWindow::on_pushButton0_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "0");

}

void MainWindow::on_pushButtonAdd_clicked()
{
temp = temp + ui->lineEdit->text().toDouble();
result = temp;
ui->lineEdit->setText("");
}

void MainWindow::on_pushButtonSubtract_clicked()
{

}

void MainWindow::on_pushButtonEquals_clicked()
{
ui->lineEdit->setText(QString("%1").arg(result));
}

void MainWindow::on_pushButtonMultiply_clicked()
{

}

void MainWindow::on_pushButtonDivide_clicked()
{

}

void MainWindow::on_pushButtonClear_clicked()
{
    ui->lineEdit->setText("");
}

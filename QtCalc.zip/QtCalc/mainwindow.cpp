#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include <QString>
#include <cmath>

static double temp, temp2;
static double result;
static int addc = 0, mulc = 0, divc = 0, subc = 0, powc = 0, sqrtc = 0;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{   
    delete ui;
}


void MainWindow::on_pushButton1_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "1");

}

void MainWindow::on_pushButton2_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "2");

}

void MainWindow::on_pushButton3_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "3");

}

void MainWindow::on_pushButton4_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "4");

}

void MainWindow::on_pushButton5_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "5");

}

void MainWindow::on_pushButton6_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "6");

}

void MainWindow::on_pushButton7_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "7");

}

void MainWindow::on_pushButton8_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "8");

}

void MainWindow::on_pushButton9_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "9");

}

void MainWindow::on_pushButton0_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + "0");

}

void MainWindow::on_pushButtonDec_clicked()
{
    ui->lineEdit->setText(ui->lineEdit->text() + ".");

}

void MainWindow::on_pushButtonAdd_clicked()
{
    temp = number_reader();
    ui->lineEdit->setText("");
    addc = 1;
    divc = 0;
    mulc = 0;
    subc = 0;
    powc = 0;
    sqrtc = 0;

}

void MainWindow::on_pushButtonSubtract_clicked()
{
    temp = number_reader();
    ui->lineEdit->setText("");
    addc = 0;
    divc = 0;
    mulc = 0;
    subc = 1;
    powc = 0;
    sqrtc = 0;
}

void MainWindow::on_pushButtonMultiply_clicked()
{
    temp = number_reader();
    ui->lineEdit->setText("");
    addc = 0;
    divc = 0;
    mulc = 1;
    subc = 0;
    powc = 0;
    sqrtc = 0;

}

void MainWindow::on_pushButtonDivide_clicked()
{
    temp = number_reader();
    ui->lineEdit->setText("");
    addc = 0;
    divc = 1;
    mulc = 0;
    subc = 0;
    powc = 0;
    sqrtc = 0;

}

void MainWindow::on_pushButtonPow_clicked()
{
    temp = number_reader();
    ui->lineEdit->setText("");
    addc = 0;
    divc = 0;
    mulc = 0;
    subc = 0;
    powc = 1;
    sqrtc = 0;

}

void MainWindow::on_pushButtonSqrt_clicked()
{
    temp = number_reader();
    result = sqrt(temp);
    ui->lineEdit->setText(QString("%1").arg(result));
    addc = 0;
    divc = 0;
    mulc = 0;
    subc = 0;
    powc = 0;
    sqrtc = 1;

}

void MainWindow::on_pushButtonClear_clicked()
{
    ui->lineEdit->setText("");
}

void MainWindow::on_pushButtonEquals_clicked()
{

    temp2 = number_reader();

    if (addc > 0){
        result = temp + temp2;
        ui->lineEdit->setText(QString("%1").arg(result));
    }
    if (subc > 0) {
        result = temp - temp2;
        ui->lineEdit->setText(QString("%1").arg(result));
    }
    if (mulc > 0) {
        result = temp * temp2;
        ui->lineEdit->setText(QString("%1").arg(result));
    }
    if (divc > 0) {
        result = temp / temp2;
        ui->lineEdit->setText(QString("%1").arg(result));
    }
    if (powc > 0) {
        result = pow(temp, temp2);
        ui->lineEdit->setText(QString("%1").arg(result));
    }
}

double MainWindow::number_reader() {
    double num1;
    QString s;
    s = ui->lineEdit->text();
    num1 = s.toDouble();
    return num1;
}
